SALT_API = {"url": "",
            "user": "",
            "password": ""
            }

Cobbler_API = {"url": "",
            "user": "",
            "password": ""
            }

# salt result
RETURNS_MYSQL = {"host": "localhost",
               "port": 63306,
               "database": "salt",
               "user": "salt",
               "password": "salt"
                }

SERVICE = {"nginx": "nginx",
           "php": "php",
           "mysql": "mysql",
           "sysinit": "sysinit",
           "logstash": "logstash",
           "zabbix": "zabbix",
           "redis": "redis",
           "memcached": "memcached"
          }

OMS_MYSQL = {"host": "localhost",
               "port": 63306,
               "database": "oms",
               "user": "root",
               "password": ""
                }
