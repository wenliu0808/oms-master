oms
===

OMS运维管理平台

写在前言：
  分享，平台里的东西是采用各家之精华，自己融合才有了那么个东西，发表OMS博客那天，答应过后续开源，那么今天就把它分享出来
  学习，自我赶脚代码不是很好，分享出来; 希望得到学习，毕竟闭门造车不好嘛。希望得到反馈，谢谢~
  总结，从13年底就想写这么个东西，刚好下半年有空，就利用9月份把这个写了，算是对自动化运维一个小小总结，里面还有不够好的地方，希望可以得到交流，毕竟每人角度不一，观点也不一样。
        感谢蝴蝶运维老大支持，小马哥代码指点迷津，绿肥在OMS平台写的时候提供帮助~

  redhat.binbin@gmail.com   //欢迎来件~,TKS ALL~

组件要求查看requirements.txt，安装查看install.txt

OMS管理平台界面
![主页](https://github.com/binbin91/oms/raw/master/demo/install.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/install_record.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/key.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/module.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/command_exec.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/code_deploy.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/host_list.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/server_asset.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/device_asset.jpg)
![主页](https://github.com/binbin91/oms/raw/master/demo/data_center.jpg)

